package com.mindgate.pojo;

public interface Gretings {
	void greet();

}
