package com.mindgate.pojo;

public class GoodMorningGreater implements Gretings {

	@Override
	public void greet() {
		System.out.println("Good Morning");
	}

}
